//
//  CoroselModel.swift
//  Tata Aig
//
//  Created by Abhinav Sharma on 26/03/24.
//

import Foundation
//MARK: - CoroselModel
struct CoroselModel: Codable {
    let data: ChildrenModel?
}

struct ChildrenModel: Codable {
    let children: [Imagedata]?
}

struct Imagedata: Codable {
    let data: ChildData?
}

struct ChildData: Codable {
    let thumbnail: String?
    let author_fullname: String?
}
//MARK: - DataManager class for storing the response locally:
class DataManager {
    private let userDefaults = UserDefaults.standard
    private let coroselKey = "coroselData"
    
    
    /// Here we get the data from the local
    /// - Returns: return corosel data
    func fetchCachedData() -> CoroselModel? {
          if let cachedData = userDefaults.data(forKey: coroselKey) {
              do {
                  let decoder = JSONDecoder()
                  let coroselModel = try decoder.decode(CoroselModel.self, from: cachedData)
                  return coroselModel
              } catch {
                  print("Error decoding data: \(error)")
                  return nil
              }
          } else {
              return nil
          }
      }
    
    /// Here save data to local
    /// - Parameter coroselModel: get the corosel from local
    func saveDataToLocal(_ coroselModel: CoroselModel) {
        do {
            let encoder = JSONEncoder()
            let encodedData = try encoder.encode(coroselModel)
            userDefaults.set(encodedData, forKey: coroselKey)
        } catch {
            print("Error encoding data: \(error)")
        }
    }
}

