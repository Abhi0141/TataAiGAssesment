//
//  Uitility.swift
//  Tata Aig
//
//  Created by Abhinav Sharma on 26/03/24.
//

import UIKit
import Network
import SDWebImage

class Uitility {
    
    static var shared = Uitility()
    

}

class NetworkReachability {
    let monitor = NWPathMonitor()
    
    init() {
        monitor.pathUpdateHandler = { path in
            if path.status == .satisfied {
                print("Network is reachable")
            } else {
                print("Network is not reachable")
            }
        }
        
        let queue = DispatchQueue(label: "NetworkMonitor")
        monitor.start(queue: queue)
    }
}

extension UIImageView {
  func quickSetImage(url: String) {
    if let image = SDImageCache.shared.imageFromDiskCache(forKey: url) {
      self.image = image
    } else {
        self.sd_setImage(with: URL(string: url), placeholderImage: UIImage(named: StringConstants.placeHolderImage))
    }
  }
}
