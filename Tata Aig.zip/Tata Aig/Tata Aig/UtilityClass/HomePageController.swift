//
//  HomePageController.swift
//  Spyne
//
//  Created by Abhinav Sharma on 22/08/23.
//  Copyright © 2023 Spyne. All rights reserved.
//

import UIKit

class HomePageController: UIPageControl {

    let dotSize: CGFloat = 7
    let dotSpacing: CGFloat = 18
    let currentDotSize: CGFloat = 12

    override var currentPage: Int {
        didSet {
            updateDots()
        }
    }

    override var numberOfPages: Int {
        didSet {
            updateDots()
        }
    }

    override func layoutSubviews() {
        super.layoutSubviews()

        updateDots()
    }

    private func updateDots() {
        for (index, dot) in subviews.enumerated() {
            dot.removeFromSuperview()
        }

        let totalWidth = CGFloat(numberOfPages) * dotSize + CGFloat(numberOfPages - 1) * dotSpacing
        let startX = (bounds.width - totalWidth) / 2
        let startY = (bounds.height - currentDotSize) / 2
        var previousDotMaxX = startX

        for index in 0..<numberOfPages {
            let dot = UIView()
            dot.frame.size = CGSize(width: dotSize, height: dotSize)

            if index == currentPage {
                // Selected dot
                dot.frame.origin.x = previousDotMaxX
                dot.frame.origin.y = startY
                dot.backgroundColor = UIColor.lightGray
                let labelWidth: CGFloat = 31 // Set the desired width of the label

                let label = UILabel(frame: CGRect(x: (dotSize - labelWidth) / 2, y: (dotSize - 18) / 2, width: labelWidth, height: 18))
                label.textAlignment = .center
                label.font = UIFont.systemFont(ofSize: 10)
                label.textColor = UIColor.white
                label.backgroundColor = UIColor.black
                label.layer.cornerRadius = label.frame.height / 2 // Set corner radius to make it a semi-circle
                label.clipsToBounds = true
                label.text = "\(currentPage + 1)/\(numberOfPages)"
                dot.addSubview(label)

                dot.bringSubviewToFront(label) // Bring the label to the front

                previousDotMaxX = dot.frame.maxX + dotSpacing // Add spacing of dotSpacing pixels for the selected dot and the next dot
            } else {
                // Other unselected dots
                dot.frame.origin.x = previousDotMaxX
                dot.frame.origin.y = startY

                dot.layer.cornerRadius = dot.frame.height / 2 // Set corner radius to make it a circle
                dot.backgroundColor = UIColor.lightGray

                previousDotMaxX = dot.frame.maxX + dotSpacing // Add spacing of dotSpacing pixels between dots
            }

            addSubview(dot)
        }
    }

}
