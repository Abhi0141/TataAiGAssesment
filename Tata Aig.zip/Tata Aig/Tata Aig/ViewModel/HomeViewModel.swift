import KRProgressHUD
// MARK: Protocol for passing API response
protocol HomeViewModelDelegate {
    func coroselSuccessResponse(model: CoroselModel)
    func coroselErrorResponse(error: String)
}

import Foundation
// MARK: HomeViewModel
class HomeViewModel: BaseViewModel {
    
    var delegate: HomeViewModelDelegate?
    
    /// fetchCoroselData
    func fetchCoroselData() {
        KRProgressHUD.show()
        self.fetchDataFromAPI(url: StringConstants.CororselAPIUrl, method: .get, responseType: CoroselModel.self) { result in
            switch result {
            case .success(let model):
                print("Received model: \(model)")
                KRProgressHUD.dismiss()
                self.delegate?.coroselSuccessResponse(model: model)
            case .failure(let error):
                print("Error fetching data: \(error)")
                self.delegate?.coroselErrorResponse(error: error.localizedDescription)
            }
        }
    }
}
