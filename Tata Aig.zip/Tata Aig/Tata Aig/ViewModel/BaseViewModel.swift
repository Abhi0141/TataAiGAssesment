//
//  BaseViewModel.swift
//  Tata Aig
//
//  Created by Abhinav Sharma on 26/03/24.
//

import UIKit
// MARK: Base class for API calling
class BaseViewModel {
    
    enum HTTPMethod: String {
        case get = "GET"
    }
    
    /// Here we call the API using URL request
    /// - Parameters:
    ///   - url: API request URL
    ///   - method: method type of API
    ///   - responseType: created geneic response type foe parsing response
    ///   - completion: Error Handling
    func fetchDataFromAPI<T: Codable>(url: String, method: HTTPMethod, responseType: T.Type, completion: @escaping (Result<T, Error>) -> Void) {
        // Prepare request
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = method.rawValue
        
        // Perform network request
        URLSession.shared.dataTask(with: request) { data, response, error in
            // Check for errors
            if let error = error {
                completion(.failure(error))
                return
            }
            
            // Ensure there is data
            guard let data = data else {
                let error = NSError(domain: "YourApp", code: 0, userInfo: [NSLocalizedDescriptionKey: "No data received"])
                completion(.failure(error))
                return
            }
            
            // Parse data and create the specified model
            do {
                let model = try JSONDecoder().decode(T.self, from: data)
                completion(.success(model))
            } catch {
                completion(.failure(error))
            }
        }.resume()
    }
    
}
