//
//  StringConstants.swift
//  Tata Aig
//
//  Created by Abhinav Sharma on 26/03/24.
//

import Foundation
//MARK: - Defined strings
struct StringConstants {
    static let imageCoroselcell = "ImageCarouselCollectionViewCell"
    static let CororselAPIUrl = "https://www.reddit.com/r/Wallstreetbets/top.json?limit=50&t=year"
    static let placeHolderImage = "Aig"
}
