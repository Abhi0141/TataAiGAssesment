//
//  ListDataViewController.swift
//  Tata Aig
//
//  Created by Abhinav Sharma on 27/03/24.
//

import UIKit
import KRProgressHUD
class ListDataViewController: UIViewController {
    
    // MARK: - @IBOutlet
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var imageView: UIImageView!
    
    // MARK: - Defined varibales
    var selectedName = String()
    var selectedImageURL = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetup()
    }
    
    func initialSetup(){
        
        imageView.layer.borderWidth = 1
        imageView.layer.cornerRadius = 12
        imageView.layer.borderColor = UIColor.lightGray.cgColor
        self.nameLabel.text = selectedName
        self.imageView.quickSetImage(url: selectedImageURL)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
            KRProgressHUD.dismiss()
        }
        
    }
    // MARK: - defined @IBAction
    @IBAction func backButtonTapped(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
}
