//
//  ViewController.swift
//  Tata Aig
//
//  Created by Abhinav Sharma on 23/03/24.
//

import UIKit
import Network
import KRProgressHUD

class HomePageViewController: UIViewController , UISearchBarDelegate{
    //MARK: - Outlets
    
    
    @IBOutlet var homePagecontroller: HomePageController!
    @IBOutlet var collectionViewHeight: NSLayoutConstraint!
    @IBOutlet var scrollView: UIScrollView!
    @IBOutlet var tableViewHeightconstraint: NSLayoutConstraint!
    @IBOutlet var imageCarouselCollectionView: UICollectionView!
    @IBOutlet var contentSearchBar: UISearchBar!
    @IBOutlet var dataListTableView: UITableView!
    
    
    //MARK: - Defined Vaiables
    var timer : Timer?
    var arrayOfImages = [String]()
    var arrayOfNameData = [String]()
    var filteredData: [String] = []
    var viewModel: HomeViewModel?
    let dataManager = DataManager()
    var isConnected = false
    private let monitor = NWPathMonitor()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel = HomeViewModel()
        viewModel?.delegate = self
        initialSetup()
        checkReachiblity()
        startTimer()
    }
    //MARK: - Function for handling connection checkReachiblity
    func checkReachiblity() {
        monitor.pathUpdateHandler = { [weak self] path in
            DispatchQueue.main.async {
                self?.handleNetworkStatus(path.status)
            }
        }
        let queue = DispatchQueue(label: "NetworkMonitor")
        monitor.start(queue: queue)
        if isConnected {
            // Fetch data from remote database
            self.viewModel?.fetchCoroselData()
        } else {
            // Fetch cached data from local storage
            if let cachedData = dataManager.fetchCachedData() {
                print(cachedData)
            } else {
                print("No cached data available")
            }
        }
    }
    //MARK: - Start the timer
    private func startTimer() {
        stopTimer()
        
        timer = Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(timerFired), userInfo: nil, repeats: true)
    }
    //MARK: - Stop and invalidate the timer
    private func stopTimer() {
        
        timer?.invalidate()
        timer = nil
    }
    
    @objc private func timerFired() {
        let nextPage = (homePagecontroller.currentPage + 1) % homePagecontroller.numberOfPages
        homePagecontroller.currentPage = nextPage
        
        let indexPath = IndexPath(item: nextPage, section: 0)
        imageCarouselCollectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
    }
    
    //MARK: - Function for handling network status
    private func handleNetworkStatus(_ status: NWPath.Status) {
        switch status {
        case .satisfied:
            print("Network is reachable")
            isConnected = true
            self.viewModel?.fetchCoroselData()
        case .unsatisfied:
            isConnected = false
            self.showAlert()
        case .requiresConnection:
            print("Network connection is required")
            self.showAlert()
            isConnected = false
        @unknown default:
            print("Unknown network status")
            isConnected = false
            
        }
    }
    
    //MARK: - Class Methods
    /// Initial ui And api calling setup
    func initialSetup() {
        homePagecontroller.numberOfPages =  4
        homePagecontroller.currentPage = 0
        viewModel?.fetchCoroselData()
        contentSearchBar.delegate = self
        imageCarouselCollectionView.delegate = self
        imageCarouselCollectionView.dataSource = self
        scrollView.delegate = self
        self.imageCarouselCollectionView.register(UINib(nibName: StringConstants.imageCoroselcell, bundle: nil) ,forCellWithReuseIdentifier: StringConstants.imageCoroselcell)
        
    }
    //MARK: - Function for Alert notification when network is unavailble
    func showAlert() {
        
        let alertController = UIAlertController(title: "No Internet", message: "Please connect to Interent", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction!) in
            print("OK button tapped")
        }
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion:nil)
    }
    //MARK: - Function for handling searchBar functionality.
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            filteredData = arrayOfNameData
        } else {
            filteredData = arrayOfNameData.filter { $0.localizedCaseInsensitiveContains(searchText) }
        }
        dataListTableView.reloadData()
    }
    
}

//MARK: - extention of  HomePageViewController  for imageCarouselCollectionView
extension HomePageViewController: UICollectionViewDelegate, UICollectionViewDataSource , UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrayOfImages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = imageCarouselCollectionView.dequeueReusableCell(withReuseIdentifier: "ImageCarouselCollectionViewCell", for: indexPath) as? ImageCarouselCollectionViewCell else {return UICollectionViewCell()}
        cell.imageView.image = nil
        cell.configureCell(imageUrl: arrayOfImages[indexPath.row] )
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: imageCarouselCollectionView.frame.width , height: 190)
    }
    
    
}
//MARK: - extention of  HomePageViewController  for dataListTableViewCell
extension HomePageViewController: UITableViewDelegate , UITableViewDataSource  {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = dataListTableView.dequeueReusableCell(withIdentifier: "DataListTableViewCell", for: indexPath) as? DataListTableViewCell else{return UITableViewCell()}
        let nameData = filteredData[indexPath.row]
        cell.configureCell(imageUrl: arrayOfImages[indexPath.row], imageLabel: nameData)
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        KRProgressHUD.show()
        let story = UIStoryboard(name: "Main", bundle: nil)
        guard let ListDataViewController = story.instantiateViewController(withIdentifier: "ListDataViewController") as? ListDataViewController else {
            return
        }
        ListDataViewController.selectedName = filteredData[indexPath.row]
        ListDataViewController.selectedImageURL = arrayOfImages[indexPath.row]
        self.navigationController?.pushViewController(ListDataViewController, animated: true)
    }
    
    
}
//MARK: - extention of  HomePageViewController  for confirming HomeViewModelDelegate and data passing
extension HomePageViewController: HomeViewModelDelegate {
    
    func coroselSuccessResponse(model: CoroselModel) {
        self.arrayOfImages = model.data?.children?.compactMap { $0.data?.thumbnail } ?? [""]
        self.arrayOfNameData = model.data?.children?.compactMap { $0.data?.author_fullname } ?? [""]
        filteredData = arrayOfNameData
        dataManager.saveDataToLocal(model)
        DispatchQueue.main.async {
            self.imageCarouselCollectionView.reloadData()
            self.tableViewHeightconstraint.constant = CGFloat.greatestFiniteMagnitude
            self.dataListTableView.layoutIfNeeded()
            self.tableViewHeightconstraint.constant = (self.dataListTableView.contentSize.height)
            self.dataListTableView.reloadData()
        }
    }
    
    func coroselErrorResponse(error: String) {
        print(error)
    }
    
    
}
//MARK: - extention of  HomePageViewController  for handling UIScrollViewDelegate:
extension HomePageViewController : UIScrollViewDelegate{
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
        let visibleRect = CGRect(origin: imageCarouselCollectionView.contentOffset, size: imageCarouselCollectionView.bounds.size)
        let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)
        
        if let indexPath = imageCarouselCollectionView.indexPathForItem(at: visiblePoint) {
            homePagecontroller.currentPage = indexPath.item
        }
    }
}
