//
//  dataListTableViewCell.swift
//  Tata Aig
//
//  Created by Abhinav Sharma on 24/03/24.
//

import UIKit

class DataListTableViewCell: UITableViewCell {

    // MARK: Outlets
    @IBOutlet var itemImageView: UIImageView!
    @IBOutlet var itemNameLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    
    /// Here we config the cell
    /// - Parameters:
    ///   - imageUrl: we get the data in image url to show over imageview
    ///   - imageLabel: we get the data in image label to show over itemNameLabel
    func configureCell(imageUrl: String  , imageLabel: String){
        itemNameLabel.text = imageLabel
        itemImageView.quickSetImage(url: imageUrl)
    }
}
