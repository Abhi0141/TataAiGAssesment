//
//  ImageCarouselCollectionViewCell.swift
//  Tata Aig
//
//  Created by Abhinav Sharma on 23/03/24.
//

import UIKit
import SDWebImage
class ImageCarouselCollectionViewCell: UICollectionViewCell {
    
//    MARK: Outlets
    @IBOutlet var imageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        initialSetup()
    }
    
    /// Here we config the cell
    /// - Parameter imageUrl: we get the data in image url to show over imageview
    func configureCell(imageUrl: String) {
        self.imageView.quickSetImage(url: imageUrl)
    }
    
    func initialSetup(){
        imageView.layer.borderWidth = 1
        imageView.layer.cornerRadius = 12
        imageView.layer.borderColor = UIColor.lightGray.cgColor
    }
}
